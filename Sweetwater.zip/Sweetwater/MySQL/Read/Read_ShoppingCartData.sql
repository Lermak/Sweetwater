DELETE FROM ShoppingCart
            WHERE ProductID = (SELECT ProductID FROM Product WHERE ItemID = 'SM57')