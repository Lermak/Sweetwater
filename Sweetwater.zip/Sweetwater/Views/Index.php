<link rel="stylesheet" href="../CSS/main.css">
<script type="text/javascript" src="../Javascript/UpdateShoppingCart.js"></script>
<script type="text/javascript" src="../Javascript/UpdateTotal.js"></script>
<script type="text/javascript" src="../Javascript/RemoveItemFromCart.js"></script>
<?php 
    INCLUDE_ONCE "../Controllers/LoadFromDatabase.php";

    //print the headers for the table
    echo '<div class="Row Header">
            <div class="Col Col1 Header"></div>
            <div class="Col Col2 Header ProductName">Name</div>
            <div class="Col Col3 Header Description">Description</div>
            <div class="Col Col4 Header Price">Price</div>
            <div class="Col Col5 Header SerialNumber">SerialNumber</div>
            <div class="Col Col7 Header Available">Quantity</div></div>';
    
    $Total = 0;
    for($i = 0; $i < COUNT($_SESSION["Products"]); ++$i)//iterate through all products
    {
        //assume no items for this product are in cart
        $Quantity = 0;
        for($x=0; $x < COUNT($_SESSION["ShoppingCart"]); ++$x)//iterate through all shopping cart items
        {
            if($_SESSION["ShoppingCart"][$x]->ProductID == $_SESSION["Products"][$i]->ProductID)//if this item matches an item in the cart, set the quantity and show a row
            {
                $Quantity = $_SESSION["ShoppingCart"][$x]->Quantity;
        
                //create a row to show all the product information on
                echo '<div class="Row Row'.$i.'">
                    <div class="Col Col1 Row'.$i.'"><a href="'.$_SESSION["Products"][$i]->URL.'"><img class="ProductImage" src="'.$_SESSION["Products"][$i]->Image.'"></img></a></div>
                    <div class="Col Col2 Row'.$i.' ProductName">'.$_SESSION["Products"][$i]->Manufactrer.' - '.$_SESSION["Products"][$i]->ProductName.'</div>
                    <div class="Col Col3 Row'.$i.' Description">'.$_SESSION["Products"][$i]->Description.'</div>
                    <div class="Col Col4 Row'.$i.' Price">'.$_SESSION["Products"][$i]->Price.'</div>
                    <div class="Col Col5 Row'.$i.' SerialNumber">'.$_SESSION["Products"][$i]->SerialNumber.'</div>
                    <div class="Col Col7 Row'.$i.' Quantity"><input type="number" min="0" max="'.$_SESSION["Products"][$i]->Available.'" class="Quantity" value="'.$Quantity.'" onchange="UpdateShoppingCartQuantity(\''.$_SESSION["Products"][$i]->ItemID.'\', this.value);UpdateTotal();"></input>/'.$_SESSION["Products"][$i]->Available.'</div>
                    <div class="Col Col8 Row'.$i.' Remove"><input type="button" value="Remove" onclick="RemoveItemFromCart(\''.$_SESSION["Products"][$i]->ItemID.'\')"></button></div></div>';
                
                //sum total of all products
                $Total = $Total + ($_SESSION["Products"][$i]->Price * $Quantity);
                break;//no need to continue iterating, item was found
            }
        }
    }        
    //create a total row
    echo '<div id="Total" class="Total">Total: $'.$Total.'</div>';
?>