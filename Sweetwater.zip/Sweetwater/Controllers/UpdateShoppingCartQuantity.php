<?php 
$output = "";

$root = $_SERVER['DOCUMENT_ROOT'];
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once $root.'/Sweetwater/Includes/RunQuery.php';

//Load data from the products table
try {
    
    //create an update query
    $query = "UPDATE ShoppingCart
            SET Quantity = ".$_POST["Quantity"]." WHERE ProductID = (SELECT ProductID FROM Product WHERE ItemID = '".$_POST["ItemID"]."')";
    
    RunQuery($query);
    
    //if there were no errors performing the query
    IF(IS_NULL($_SESSION["error"]))
    {
        //if there were no errors return Success
        $output = '{"result" : "Success"}';
    }
    ELSE
    {
        $output = '{"result" : "Query failed: '.$_SESSION["error"].$query.'"}';
        $_SESSION["error"] = null;
    }
}
catch (Exception $e)
{
    $output = '{"result" : "Query failed: '.$e.'"}';
}

echo $output;
?>