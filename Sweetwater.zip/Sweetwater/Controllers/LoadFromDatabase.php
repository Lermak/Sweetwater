<?php 
$output = "";

$root = $_SERVER['DOCUMENT_ROOT'];
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once $root.'/Sweetwater/Includes/RunQuery.php';
require_once $root.'/Sweetwater/Models/Product.php';
require_once $root.'/Sweetwater/Models/ShoppingCart.php';

//Load data from the products table
try {
    
    //get the items in the table
    $query = "SELECT * FROM Product";
    
    $result = RunQuery($query);
    
    //if there were no errors performing the query
    IF(IS_NULL($_SESSION["error"]))
    {
        //create or empty a products array
        $_SESSION["Products"] = array();
        
        while($row = $result->fetch_assoc())
        {
            //create a new product object with the information in the database
            $product = new Product($row["ProductID"], $row["Image"], $row["URL"], $row["Manufactrer"], $row["ProductName"], $row["ItemID"], $row["Price"],
                $row["SerialNumber"], $row["Description"], $row["Available"]);
            
            //add that product the array
            array_push($_SESSION["Products"], $product);
        }
    }
    ELSE
    {
        $output = '{"result" : "Query failed: '.$_SESSION["error"].'"}';
        $_SESSION["error"] = null;
    }
}
catch (Exception $e)
{
    $output = '{"result" : "Query failed: '.$e.'"}';
}

//Load data from the shoppingcart table
try {
    
    //get the items in the table
    $query = "SELECT * FROM ShoppingCart";
    
    $result = RunQuery($query);
    
    //if there were no errors performing the query
    IF(IS_NULL($_SESSION["error"]))
    {
        //create or empty a products array
        $_SESSION["ShoppingCart"] = array();
        
        while($row = $result->fetch_assoc())
        {
            //create a new shoppingCart object with the information in the database
            $product = new ShoppingCart($row["ProductID"], $row["Quantity"]);
            
            //add that product the array
            array_push($_SESSION["ShoppingCart"], $product);
        }
    }
    ELSE
    {
        $output = '{"result" : "Query failed: '.$_SESSION["error"].'"}';
        $_SESSION["error"] = null;
    }
}
catch (Exception $e)
{
    $output = '{"result" : "Query failed: '.$e.'"}';
}

echo $output;



?>