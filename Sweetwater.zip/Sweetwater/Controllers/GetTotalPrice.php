<?php 
$output = "";

$root = $_SERVER['DOCUMENT_ROOT'];
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once $root.'/Sweetwater/Includes/RunQuery.php';

//Load data from the products table
try {
    
    //create an update query
    $query = "SELECT SUM(p.Price * sc.Quantity) AS Total FROM Product p INNER JOIN ShoppingCart sc ON sc.ProductID = p.ProductID";
    
    $result = RunQuery($query);
    
    //if there were no errors performing the query
    IF(IS_NULL($_SESSION["error"]))
    {
        while($row = $result->fetch_assoc())
        {
            $output = '{"result" : "Success",
                        "Total": '.$row["Total"].'}';
            break;
        }
    }
    ELSE
    {
        $output = '{"result" : "Query failed: '.$_SESSION["error"].'"}';
        $_SESSION["error"] = null;
    }
}
catch (Exception $e)
{
    $output = '{"result" : "Query failed: '.$e.'"}';
}

echo $output;
?>