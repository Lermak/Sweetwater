<?php
class ShoppingCart{
    
    public $ProductID;
    public $Quantity;
    
    public function __construct($productID,                           
                                $quantity)
    {
        $this->ProductID = $productID;
        $this->Quantity = $quantity;
    }
}
?>