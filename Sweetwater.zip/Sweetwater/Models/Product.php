<?php
class Product{
    
    public $ProductID;
    public $Image;
    public $URL;
    public $Manufactrer;
    public $ProductName;
    public $ItemID;
    public $Price;
    public $SerialNumber;
    public $Description;
    public $Available;
    
    public function __construct($productID,
                                $image,
                                $url,
                                $manufactrer,
                                $productName,
                                $itemID,
                                $price,
                                $serialNumber,
                                $description,
                                $available)
    {
        $this->ProductID = $productID;
        $this->Image = $image;
        $this->URL = $url;
        $this->Manufactrer = $manufactrer;
        $this->ProductName = $productName;
        $this->ItemID = $itemID;
        $this->Price = $price;
        $this->SerialNumber = $serialNumber;
        $this->Description = $description;
        $this->Available = $available;
    }
}
?>