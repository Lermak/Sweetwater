function RemoveItemFromCart(ItemID)
{
	var xhttp = new XMLHttpRequest();//create a new post
	  xhttp.onreadystatechange = function() {//set the callback function
		    if (this.readyState == 4 && this.status == 200) {//if the post is finsihed
		    	var result = JSON.parse(this.responseText);//parse the json
		    	if(result["result"] == "Success")//if the result is a success
		    		location.reload();//reload the page
		    	else
	    			alert(result["result"]);//otherwise show the error
		    	
			  }
	  }
	  xhttp.open("POST", "../Controllers/RemoveFromCart.php", true);
	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	  xhttp.send("ItemID='"+ItemID+"'");
}