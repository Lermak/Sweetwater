function UpdateTotal()
{
	//create new request
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {//set calback functino
		    if (this.readyState == 4 && this.status == 200) {//if the post is finished
		    	var result = JSON.parse(this.responseText);//parse the results to json
		    	if(result["result"] == "Success")//if the result was a success
		    		document.getElementById("Total").innerHTML = "Total: $" + result["Total"];//uypdate the page
		    	else
	    			alert(result["result"]);//otherwise show the error
			  }
	  }
	  xhttp.open("POST", "../Controllers/GetTotalPrice.php", true);
	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	  xhttp.send();
	
}
