function UpdateShoppingCartQuantity(ItemID, Quantity)
{
	  var xhttp = new XMLHttpRequest();//create new post
	  xhttp.onreadystatechange = function() {//set callback function
		    if (this.readyState == 4 && this.status == 200) {//if the post is fone
		    	var result = JSON.parse(this.responseText);//parse the json object
		    	if(result["result"] != "Success")//if it wansn't successful
	    			alert(result["result"]);//show the error
			  }
	  }
	  xhttp.open("POST", "../Controllers/UpdateShoppingCartQuantity.php", true);
	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	  xhttp.send("ItemID="+ItemID+"&Quantity="+Quantity);
}