<?php 
    //function to clean user input strings to prevent them from passing unwanted queries as arguments
    function CleanString($input)
    {
        $input = str_replace("'", "", $input);//replace all single quotes with empty string, this prevents the user from changing 'Select * from table' to ''+Select * from table+''
        return $input;
    }
?>