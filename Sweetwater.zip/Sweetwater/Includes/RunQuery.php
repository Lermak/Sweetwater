<?php 
    function RunQuery($query)
    {
        //pre-defined database login data
        $servername = "localhost";
        $username = "Sweetwater";
        $password = "";
        $dbname = "Sweetwater";
        // Create MySQL connection on pre-defined data
        $database = mysqli_connect($servername, $username, $password, $dbname);
        
        //clear any backlog of sql results to prevent a clog or incorrect data from the current query
        while($database->more_results() && $database->next_result())
        {
            $extraResult = $database->use_result();
            if($extraResult instanceof mysqli_result){
                $extraResult->free();
            }
        
        }
        
        //get a mysql_result object from the databse build from the provided query
        $result = $database->query($query);
        
        //if the result is null then throw a session error that the calling php page can read explaining what went wrong
        if (!$result) {
            $_SESSION["error"] = trigger_error('Invalid query: ' . $database->error);
        }

        //if everything went correctly, return the mysql_result
        return $result;
    }
?>